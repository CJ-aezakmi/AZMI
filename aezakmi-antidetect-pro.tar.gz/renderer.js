// AEZAKMI Antidetect Pro v2.0 - Renderer Process
class AEZAKMIApp {
    constructor() {
        this.profiles = [];
        this.proxies = [];
        this.selectedProfiles = new Set();
        this.currentView = 'profiles';
        this.init();
    }

    async init() {
        console.log('Initializing AEZAKMI App...');
        
        // Загружаем данные
        await this.loadProfiles();
        await this.loadProxies();
        
        // Настраиваем обработчики событий
        this.setupEventListeners();
        
        // Отображаем данные
        this.renderProfiles();
        this.renderProxies();
        this.updateCounts();
        
        // Показываем главную страницу
        this.showView('profiles');
        
        console.log('AEZAKMI App initialized successfully');
    }

    setupEventListeners() {
        // Навигация по разделам
        document.querySelectorAll('.nav-item').forEach(item => {
            item.addEventListener('click', (e) => {
                const view = e.currentTarget.dataset.view;
                this.showView(view);
            });
        });

        // Кнопка создания профиля
        document.getElementById('createProfileBtn').addEventListener('click', () => {
            this.showCreateProfileModal();
        });

        // Кнопки в модальном окне профиля
        document.getElementById('saveProfileBtn').addEventListener('click', () => {
            this.saveProfile();
        });

        document.getElementById('cancelProfileBtn').addEventListener('click', () => {
            this.hideModal('profileModal');
        });

        // Переключение табов в модальном окне
        document.querySelectorAll('.tab-button').forEach(button => {
            button.addEventListener('click', (e) => {
                this.switchTab(e.target.dataset.tab);
            });
        });

        // Прокси
        document.getElementById('addProxiesBtn').addEventListener('click', () => {
            this.addProxies();
        });

        document.getElementById('testAllProxiesBtn').addEventListener('click', () => {
            this.testAllProxies();
        });

        // Массовые действия
        document.getElementById('selectAllBtn').addEventListener('click', () => {
            this.selectAllProfiles();
        });

        document.getElementById('deleteSelectedBtn').addEventListener('click', () => {
            this.deleteSelectedProfiles();
        });

        document.getElementById('startSelectedBtn').addEventListener('click', () => {
            this.startSelectedProfiles();
        });

        // Закрытие модальных окон по клику вне их
        document.addEventListener('click', (e) => {
            if (e.target.classList.contains('modal')) {
                this.hideModal(e.target.id);
            }
        });

        // Поиск профилей
        const searchInput = document.getElementById('searchInput');
        if (searchInput) {
            searchInput.addEventListener('input', (e) => {
                this.searchProfiles(e.target.value);
            });
        }
    }

    async loadProfiles() {
        try {
            this.profiles = await window.electronAPI.getProfiles();
            console.log(`Loaded ${this.profiles.length} profiles`);
        } catch (error) {
            console.error('Error loading profiles:', error);
            this.profiles = [];
        }
    }

    async loadProxies() {
        try {
            this.proxies = await window.electronAPI.getProxies();
            console.log(`Loaded ${this.proxies.length} proxies`);
        } catch (error) {
            console.error('Error loading proxies:', error);
            this.proxies = [];
        }
    }

    showView(viewName) {
        // Скрываем все виды
        document.querySelectorAll('.view').forEach(view => {
            view.classList.add('hidden');
        });

        // Показываем выбранный вид
        const targetView = document.getElementById(`${viewName}View`);
        if (targetView) {
            targetView.classList.remove('hidden');
        }

        // Обновляем активную навигацию
        document.querySelectorAll('.nav-item').forEach(item => {
            item.classList.remove('active');
        });

        const activeNavItem = document.querySelector(`[data-view="${viewName}"]`);
        if (activeNavItem) {
            activeNavItem.classList.add('active');
        }

        this.currentView = viewName;
    }

    showCreateProfileModal(profileId = null) {
        const modal = document.getElementById('profileModal');
        const title = document.getElementById('profileModalTitle');
        
        if (profileId) {
            title.textContent = 'Редактировать профиль';
            this.loadProfileForEdit(profileId);
        } else {
            title.textContent = 'Создать новый профиль';
            this.clearProfileForm();
        }
        
        modal.classList.remove('hidden');
        this.switchTab('basic');
    }

    hideModal(modalId) {
        document.getElementById(modalId).classList.add('hidden');
    }

    switchTab(tabName) {
        // Скрываем все табы
        document.querySelectorAll('.tab-content').forEach(tab => {
            tab.classList.add('hidden');
        });

        // Показываем выбранный таб
        document.getElementById(`${tabName}Tab`).classList.remove('hidden');

        // Обновляем кнопки табов
        document.querySelectorAll('.tab-button').forEach(btn => {
            btn.classList.remove('active');
        });

        document.querySelector(`[data-tab="${tabName}"]`).classList.add('active');
    }

    clearProfileForm() {
        // Очищаем все поля формы
        document.getElementById('profileName').value = '';
        document.getElementById('profileNotes').value = '';
        document.getElementById('userAgent').value = 'auto';
        document.getElementById('screenWidth').value = '1920';
        document.getElementById('screenHeight').value = '1080';
        document.getElementById('language').value = 'ru-RU';
        document.getElementById('timezone').value = 'Europe/Moscow';
        
        // Прокси
        document.getElementById('proxyEnabled').checked = false;
        document.getElementById('proxyType').value = 'http';
        document.getElementById('proxyHost').value = '';
        document.getElementById('proxyPort').value = '';
        document.getElementById('proxyUsername').value = '';
        document.getElementById('proxyPassword').value = '';
        
        // Антидетект
        document.getElementById('canvasNoise').checked = true;
        document.getElementById('webglNoise').checked = true;
        document.getElementById('audioNoise').checked = true;
        document.getElementById('blockWebRTC').checked = true;
        document.getElementById('spoofGeolocation').checked = false;
        document.getElementById('latitude').value = '';
        document.getElementById('longitude').value = '';
        
        document.getElementById('profileId').value = '';
    }

    loadProfileForEdit(profileId) {
        const profile = this.profiles.find(p => p.id === profileId);
        if (!profile) return;

        document.getElementById('profileName').value = profile.name || '';
        document.getElementById('profileNotes').value = profile.notes || '';
        document.getElementById('userAgent').value = profile.userAgent || 'auto';
        document.getElementById('screenWidth').value = profile.screenWidth || '1920';
        document.getElementById('screenHeight').value = profile.screenHeight || '1080';
        document.getElementById('language').value = profile.language || 'ru-RU';
        document.getElementById('timezone').value = profile.timezone || 'Europe/Moscow';
        
        // Прокси
        document.getElementById('proxyEnabled').checked = profile.proxy?.enabled || false;
        document.getElementById('proxyType').value = profile.proxy?.type || 'http';
        document.getElementById('proxyHost').value = profile.proxy?.host || '';
        document.getElementById('proxyPort').value = profile.proxy?.port || '';
        document.getElementById('proxyUsername').value = profile.proxy?.username || '';
        document.getElementById('proxyPassword').value = profile.proxy?.password || '';
        
        // Антидетект
        document.getElementById('canvasNoise').checked = profile.antidetect?.canvasNoise !== false;
        document.getElementById('webglNoise').checked = profile.antidetect?.webglNoise !== false;
        document.getElementById('audioNoise').checked = profile.antidetect?.audioNoise !== false;
        document.getElementById('blockWebRTC').checked = profile.antidetect?.blockWebRTC !== false;
        document.getElementById('spoofGeolocation').checked = profile.antidetect?.spoofGeolocation || false;
        document.getElementById('latitude').value = profile.latitude || '';
        document.getElementById('longitude').value = profile.longitude || '';
        
        document.getElementById('profileId').value = profileId;
    }

    async saveProfile() {
        try {
            const profileData = {
                id: document.getElementById('profileId').value || null,
                name: document.getElementById('profileName').value,
                notes: document.getElementById('profileNotes').value,
                userAgent: document.getElementById('userAgent').value,
                screenWidth: parseInt(document.getElementById('screenWidth').value),
                screenHeight: parseInt(document.getElementById('screenHeight').value),
                language: document.getElementById('language').value,
                timezone: document.getElementById('timezone').value,
                proxy: {
                    enabled: document.getElementById('proxyEnabled').checked,
                    type: document.getElementById('proxyType').value,
                    host: document.getElementById('proxyHost').value,
                    port: document.getElementById('proxyPort').value,
                    username: document.getElementById('proxyUsername').value,
                    password: document.getElementById('proxyPassword').value
                },
                antidetect: {
                    canvasNoise: document.getElementById('canvasNoise').checked,
                    webglNoise: document.getElementById('webglNoise').checked,
                    audioNoise: document.getElementById('audioNoise').checked,
                    blockWebRTC: document.getElementById('blockWebRTC').checked,
                    spoofGeolocation: document.getElementById('spoofGeolocation').checked
                },
                latitude: document.getElementById('latitude').value,
                longitude: document.getElementById('longitude').value
            };

            if (!profileData.name.trim()) {
                alert('Введите название профиля');
                return;
            }

            const savedProfile = await window.electronAPI.saveProfile(profileData);
            
            // Обновляем локальный список
            const existingIndex = this.profiles.findIndex(p => p.id === savedProfile.id);
            if (existingIndex >= 0) {
                this.profiles[existingIndex] = savedProfile;
            } else {
                this.profiles.push(savedProfile);
            }

            this.renderProfiles();
            this.updateCounts();
            this.hideModal('profileModal');
            
            this.showNotification('Профиль сохранен успешно', 'success');
        } catch (error) {
            console.error('Error saving profile:', error);
            this.showNotification('Ошибка при сохранении профиля', 'error');
        }
    }

    renderProfiles() {
        const container = document.getElementById('profilesContainer');
        if (!container) return;

        if (this.profiles.length === 0) {
            container.innerHTML = `
                <div class="empty-state">
                    <div class="empty-icon">👤</div>
                    <h3>Нет профилей</h3>
                    <p>Создайте первый профиль для начала работы</p>
                    <button class="btn btn-primary" onclick="app.showCreateProfileModal()">
                        Создать профиль
                    </button>
                </div>
            `;
            return;
        }

        container.innerHTML = this.profiles.map(profile => `
            <div class="profile-card ${this.selectedProfiles.has(profile.id) ? 'selected' : ''}" 
                 data-profile-id="${profile.id}">
                <div class="profile-header">
                    <div class="profile-checkbox">
                        <input type="checkbox" ${this.selectedProfiles.has(profile.id) ? 'checked' : ''}
                               onchange="app.toggleProfileSelection('${profile.id}', this.checked)">
                    </div>
                    <div class="profile-name">${profile.name}</div>
                    <div class="profile-status ${profile.isRunning ? 'running' : 'stopped'}">
                        ${profile.isRunning ? 'Запущен' : 'Остановлен'}
                    </div>
                </div>
                
                <div class="profile-info">
                    <div class="info-row">
                        <span class="label">Прокси:</span>
                        <span class="value">${profile.proxy?.enabled ? 
                            `${profile.proxy.type}://${profile.proxy.host}:${profile.proxy.port}` : 
                            'Не используется'}</span>
                    </div>
                    <div class="info-row">
                        <span class="label">User Agent:</span>
                        <span class="value">${profile.userAgent === 'auto' ? 'Автоматический' : 'Пользовательский'}</span>
                    </div>
                    <div class="info-row">
                        <span class="label">Разрешение:</span>
                        <span class="value">${profile.screenWidth}x${profile.screenHeight}</span>
                    </div>
                    <div class="info-row">
                        <span class="label">Создан:</span>
                        <span class="value">${new Date(profile.createdAt).toLocaleDateString()}</span>
                    </div>
                </div>
                
                <div class="profile-actions">
                    <button class="btn btn-primary" onclick="app.launchProfile('${profile.id}')">
                        🚀 Запустить
                    </button>
                    <button class="btn btn-secondary" onclick="app.showCreateProfileModal('${profile.id}')">
                        ✏️ Изменить
                    </button>
                    <button class="btn btn-secondary" onclick="app.cloneProfile('${profile.id}')">
                        📋 Клонировать
                    </button>
                    <button class="btn btn-danger" onclick="app.deleteProfile('${profile.id}')">
                        🗑️ Удалить
                    </button>
                </div>
            </div>
        `).join('');
    }

    async launchProfile(profileId) {
        try {
            this.showNotification('Запуск профиля...', 'info');
            
            const result = await window.electronAPI.launchProfile(profileId);
            
            if (result.success) {
                // Обновляем статус профиля
                const profile = this.profiles.find(p => p.id === profileId);
                if (profile) {
                    profile.isRunning = true;
                    profile.lastUsed = new Date().toISOString();
                }
                
                this.renderProfiles();
                this.showNotification('Профиль запущен успешно', 'success');
            }
        } catch (error) {
            console.error('Error launching profile:', error);
            this.showNotification('Ошибка при запуске профиля', 'error');
        }
    }

    async deleteProfile(profileId) {
        if (!confirm('Вы уверены, что хотите удалить этот профиль?')) {
            return;
        }

        try {
            await window.electronAPI.deleteProfile(profileId);
            
            this.profiles = this.profiles.filter(p => p.id !== profileId);
            this.selectedProfiles.delete(profileId);
            
            this.renderProfiles();
            this.updateCounts();
            this.showNotification('Профиль удален', 'success');
        } catch (error) {
            console.error('Error deleting profile:', error);
            this.showNotification('Ошибка при удалении профиля', 'error');
        }
    }

    cloneProfile(profileId) {
        const profile = this.profiles.find(p => p.id === profileId);
        if (!profile) return;

        const clonedProfile = {
            ...profile,
            id: null,
            name: `${profile.name} (копия)`,
            createdAt: undefined,
            isRunning: false
        };

        this.showCreateProfileModal();
        
        // Заполняем форму данными клонируемого профиля
        setTimeout(() => {
            document.getElementById('profileName').value = clonedProfile.name;
            document.getElementById('profileNotes').value = clonedProfile.notes || '';
            document.getElementById('userAgent').value = clonedProfile.userAgent || 'auto';
            document.getElementById('screenWidth').value = clonedProfile.screenWidth || '1920';
            document.getElementById('screenHeight').value = clonedProfile.screenHeight || '1080';
            document.getElementById('language').value = clonedProfile.language || 'ru-RU';
            document.getElementById('timezone').value = clonedProfile.timezone || 'Europe/Moscow';
            
            if (clonedProfile.proxy) {
                document.getElementById('proxyEnabled').checked = clonedProfile.proxy.enabled || false;
                document.getElementById('proxyType').value = clonedProfile.proxy.type || 'http';
                document.getElementById('proxyHost').value = clonedProfile.proxy.host || '';
                document.getElementById('proxyPort').value = clonedProfile.proxy.port || '';
                document.getElementById('proxyUsername').value = clonedProfile.proxy.username || '';
                document.getElementById('proxyPassword').value = clonedProfile.proxy.password || '';
            }
            
            if (clonedProfile.antidetect) {
                document.getElementById('canvasNoise').checked = clonedProfile.antidetect.canvasNoise !== false;
                document.getElementById('webglNoise').checked = clonedProfile.antidetect.webglNoise !== false;
                document.getElementById('audioNoise').checked = clonedProfile.antidetect.audioNoise !== false;
                document.getElementById('blockWebRTC').checked = clonedProfile.antidetect.blockWebRTC !== false;
                document.getElementById('spoofGeolocation').checked = clonedProfile.antidetect.spoofGeolocation || false;
            }
            
            document.getElementById('latitude').value = clonedProfile.latitude || '';
            document.getElementById('longitude').value = clonedProfile.longitude || '';
        }, 100);
    }

    toggleProfileSelection(profileId, selected) {
        if (selected) {
            this.selectedProfiles.add(profileId);
        } else {
            this.selectedProfiles.delete(profileId);
        }
        this.updateSelectedCount();
    }

    selectAllProfiles() {
        const checkboxes = document.querySelectorAll('.profile-checkbox input[type="checkbox"]');
        const allSelected = this.selectedProfiles.size === this.profiles.length;
        
        if (allSelected) {
            this.selectedProfiles.clear();
            checkboxes.forEach(cb => cb.checked = false);
        } else {
            this.profiles.forEach(profile => this.selectedProfiles.add(profile.id));
            checkboxes.forEach(cb => cb.checked = true);
        }
        
        this.updateSelectedCount();
        this.renderProfiles();
    }

    async deleteSelectedProfiles() {
        if (this.selectedProfiles.size === 0) {
            alert('Выберите профили для удаления');
            return;
        }

        if (!confirm(`Удалить ${this.selectedProfiles.size} выбранных профилей?`)) {
            return;
        }

        try {
            for (const profileId of this.selectedProfiles) {
                await window.electronAPI.deleteProfile(profileId);
            }
            
            this.profiles = this.profiles.filter(p => !this.selectedProfiles.has(p.id));
            this.selectedProfiles.clear();
            
            this.renderProfiles();
            this.updateCounts();
            this.showNotification('Выбранные профили удалены', 'success');
        } catch (error) {
            console.error('Error deleting profiles:', error);
            this.showNotification('Ошибка при удалении профилей', 'error');
        }
    }

    async startSelectedProfiles() {
        if (this.selectedProfiles.size === 0) {
            alert('Выберите профили для запуска');
            return;
        }

        try {
            for (const profileId of this.selectedProfiles) {
                await this.launchProfile(profileId);
                // Небольшая задержка между запусками
                await new Promise(resolve => setTimeout(resolve, 1000));
            }
        } catch (error) {
            console.error('Error starting profiles:', error);
            this.showNotification('Ошибка при запуске профилей', 'error');
        }
    }

    addProxies() {
        const proxyText = document.getElementById('proxyInput').value.trim();
        if (!proxyText) {
            alert('Введите прокси для добавления');
            return;
        }

        const lines = proxyText.split('\n').filter(line => line.trim());
        const newProxies = [];

        lines.forEach(line => {
            const proxy = this.parseProxyLine(line.trim());
            if (proxy) {
                proxy.id = this.generateId();
                proxy.status = 'untested';
                proxy.addedAt = new Date().toISOString();
                newProxies.push(proxy);
            }
        });

        if (newProxies.length > 0) {
            this.proxies.push(...newProxies);
            this.saveProxies();
            this.renderProxies();
            this.updateCounts();
            document.getElementById('proxyInput').value = '';
            this.showNotification(`Добавлено ${newProxies.length} прокси`, 'success');
        } else {
            this.showNotification('Не удалось распознать прокси', 'error');
        }
    }

    parseProxyLine(line) {
        // Поддерживаем разные форматы прокси
        let match;

        // Формат: protocol://username:password@host:port
        match = line.match(/^(https?|socks[45]):\/\/([^:]+):([^@]+)@([^:]+):(\d+)$/);
        if (match) {
            return {
                type: match[1],
                host: match[4],
                port: parseInt(match[5]),
                username: match[2],
                password: match[3]
            };
        }

        // Формат: host:port:username:password
        match = line.match(/^([^:]+):(\d+):([^:]+):(.+)$/);
        if (match) {
            return {
                type: 'http',
                host: match[1],
                port: parseInt(match[2]),
                username: match[3],
                password: match[4]
            };
        }

        // Формат: host:port
        match = line.match(/^([^:]+):(\d+)$/);
        if (match) {
            return {
                type: 'http',
                host: match[1],
                port: parseInt(match[2]),
                username: '',
                password: ''
            };
        }

        return null;
    }

    renderProxies() {
        const container = document.getElementById('proxiesContainer');
        if (!container) return;

        if (this.proxies.length === 0) {
            container.innerHTML = `
                <div class="empty-state">
                    <div class="empty-icon">🌐</div>
                    <h3>Нет прокси</h3>
                    <p>Добавьте прокси серверы для использования в профилях</p>
                </div>
            `;
            return;
        }

        container.innerHTML = this.proxies.map(proxy => `
            <div class="proxy-item">
                <div class="proxy-info">
                    <div class="proxy-address">${proxy.type}://${proxy.host}:${proxy.port}</div>
                    <div class="proxy-auth">${proxy.username ? `${proxy.username}:${proxy.password}` : 'Без авторизации'}</div>
                    <div class="proxy-added">Добавлен: ${new Date(proxy.addedAt).toLocaleDateString()}</div>
                </div>
                <div class="proxy-status ${proxy.status}">
                    ${this.getProxyStatusText(proxy.status)}
                </div>
                <div class="proxy-actions">
                    <button class="btn btn-sm btn-secondary" onclick="app.testProxy('${proxy.id}')">
                        Проверить
                    </button>
                    <button class="btn btn-sm btn-danger" onclick="app.deleteProxy('${proxy.id}')">
                        Удалить
                    </button>
                </div>
            </div>
        `).join('');
    }

    getProxyStatusText(status) {
        const statusMap = {
            'untested': 'Не проверен',
            'working': 'Работает',
            'failed': 'Не работает',
            'testing': 'Проверяется...'
        };
        return statusMap[status] || status;
    }

    async testProxy(proxyId) {
        const proxy = this.proxies.find(p => p.id === proxyId);
        if (!proxy) return;

        proxy.status = 'testing';
        this.renderProxies();

        try {
            const result = await window.electronAPI.testProxy(proxy);
            proxy.status = result.status;
            proxy.lastTested = new Date().toISOString();
            
            this.saveProxies();
            this.renderProxies();
            
            const message = result.success ? 'Прокси работает' : 'Прокси не работает';
            const type = result.success ? 'success' : 'error';
            this.showNotification(message, type);
        } catch (error) {
            proxy.status = 'failed';
            this.renderProxies();
            this.showNotification('Ошибка при проверке прокси', 'error');
        }
    }

    async testAllProxies() {
        if (this.proxies.length === 0) {
            alert('Нет прокси для проверки');
            return;
        }

        this.showNotification('Проверка всех прокси...', 'info');

        for (const proxy of this.proxies) {
            proxy.status = 'testing';
        }
        this.renderProxies();

        let workingCount = 0;
        for (const proxy of this.proxies) {
            try {
                const result = await window.electronAPI.testProxy(proxy);
                proxy.status = result.status;
                proxy.lastTested = new Date().toISOString();
                
                if (result.success) {
                    workingCount++;
                }
            } catch (error) {
                proxy.status = 'failed';
            }
            
            // Небольшая задержка между проверками
            await new Promise(resolve => setTimeout(resolve, 500));
        }

        this.saveProxies();
        this.renderProxies();
        this.showNotification(`Проверка завершена. Работает: ${workingCount}/${this.proxies.length}`, 'success');
    }

    deleteProxy(proxyId) {
        if (!confirm('Удалить этот прокси?')) return;

        this.proxies = this.proxies.filter(p => p.id !== proxyId);
        this.saveProxies();
        this.renderProxies();
        this.updateCounts();
        this.showNotification('Прокси удален', 'success');
    }

    async saveProxies() {
        try {
            await window.electronAPI.saveProxies(this.proxies);
        } catch (error) {
            console.error('Error saving proxies:', error);
        }
    }

    searchProfiles(query) {
        const cards = document.querySelectorAll('.profile-card');
        cards.forEach(card => {
            const name = card.querySelector('.profile-name').textContent.toLowerCase();
            const visible = name.includes(query.toLowerCase());
            card.style.display = visible ? 'block' : 'none';
        });
    }

    updateCounts() {
        const profileCount = document.getElementById('profileCount');
        const proxyCount = document.getElementById('proxyCount');
        
        if (profileCount) profileCount.textContent = this.profiles.length;
        if (proxyCount) proxyCount.textContent = this.proxies.length;
    }

    updateSelectedCount() {
        const selectedCount = document.getElementById('selectedCount');
        if (selectedCount) {
            selectedCount.textContent = this.selectedProfiles.size;
        }
    }

    showNotification(message, type = 'info') {
        // Создаем уведомление
        const notification = document.createElement('div');
        notification.className = `notification ${type}`;
        notification.textContent = message;
        
        // Добавляем в контейнер уведомлений
        let container = document.getElementById('notificationContainer');
        if (!container) {
            container = document.createElement('div');
            container.id = 'notificationContainer';
            container.className = 'notification-container';
            document.body.appendChild(container);
        }
        
        container.appendChild(notification);
        
        // Автоматически убираем через 3 секунды
        setTimeout(() => {
            notification.remove();
        }, 3000);
    }

    generateId() {
        return 'id_' + Math.random().toString(36).substr(2, 9) + Date.now().toString(36);
    }
}

// Инициализируем приложение
const app = new AEZAKMIApp();