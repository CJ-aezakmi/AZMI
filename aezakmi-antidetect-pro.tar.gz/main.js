const { app, BrowserWindow, ipcMain, dialog, session } = require('electron');
const path = require('path');
const fs = require('fs');

// Простая функция генерации UUID
function generateUUID() {
    return 'xxxxxxxx-xxxx-4xxx-yxxx-xxxxxxxxxxxx'.replace(/[xy]/g, function(c) {
        const r = Math.random() * 16 | 0;
        const v = c == 'x' ? r : (r & 0x3 | 0x8);
        return v.toString(16);
    });
}

// Создаем директории для профилей
const PROFILES_DIR = path.join(app.getPath('userData'), 'AEZAKMI_Profiles');
const PROXIES_FILE = path.join(app.getPath('userData'), 'proxies.json');

// Создаем директорию если не существует
if (!fs.existsSync(PROFILES_DIR)) {
    fs.mkdirSync(PROFILES_DIR, { recursive: true });
}

console.log('AEZAKMI Antidetect Pro main process loaded');

let mainWindow;
let profileWindows = new Map();

// Проверяем headless окружение
const isHeadless = !process.env.DISPLAY && process.platform === 'linux';
if (isHeadless) {
    console.log('Running in headless environment, setting up virtual display...');
    process.env.DISPLAY = ':99';
}

function createWindow() {
    mainWindow = new BrowserWindow({
        width: 1400,
        height: 900,
        title: 'AEZAKMI Antidetect Pro v2.0',
        webPreferences: {
            preload: path.join(__dirname, 'preload.js'),
            contextIsolation: true,
            nodeIntegration: false,
            webSecurity: false
        }
    });

    mainWindow.loadFile('index.html');
    
    // Открываем DevTools в режиме разработки
    if (process.argv.includes('--dev')) {
        mainWindow.webContents.openDevTools();
    }
}

app.whenReady().then(() => {
    createWindow();
    console.log('AEZAKMI Antidetect Pro is ready!');
});

app.on('window-all-closed', () => {
    if (process.platform !== 'darwin') {
        app.quit();
    }
});

app.on('activate', () => {
    if (BrowserWindow.getAllWindows().length === 0) {
        createWindow();
    }
});

// IPC Handlers для профилей
ipcMain.handle('get-profiles', async () => {
    try {
        const profiles = [];
        if (fs.existsSync(PROFILES_DIR)) {
            const folders = fs.readdirSync(PROFILES_DIR);
            for (const folder of folders) {
                const configPath = path.join(PROFILES_DIR, folder, 'config.json');
                if (fs.existsSync(configPath)) {
                    const config = JSON.parse(fs.readFileSync(configPath, 'utf8'));
                    profiles.push({ id: folder, ...config });
                }
            }
        }
        return profiles;
    } catch (error) {
        console.error('Error getting profiles:', error);
        return [];
    }
});

ipcMain.handle('save-profile', async (event, profileData) => {
    try {
        const profileId = profileData.id || generateUUID();
        const profileDir = path.join(PROFILES_DIR, profileId);
        
        if (!fs.existsSync(profileDir)) {
            fs.mkdirSync(profileDir, { recursive: true });
        }
        
        const profile = {
            ...profileData,
            id: profileId,
            createdAt: profileData.createdAt || new Date().toISOString(),
            updatedAt: new Date().toISOString()
        };
        
        fs.writeFileSync(
            path.join(profileDir, 'config.json'), 
            JSON.stringify(profile, null, 2)
        );
        
        console.log(`Profile saved: ${profile.name} (${profileId})`);
        return profile;
    } catch (error) {
        console.error('Error saving profile:', error);
        throw error;
    }
});

ipcMain.handle('delete-profile', async (event, profileId) => {
    try {
        const profileDir = path.join(PROFILES_DIR, profileId);
        if (fs.existsSync(profileDir)) {
            fs.rmSync(profileDir, { recursive: true, force: true });
            console.log(`Profile deleted: ${profileId}`);
        }
        
        // Закрываем окно профиля если оно открыто
        if (profileWindows.has(profileId)) {
            const window = profileWindows.get(profileId);
            if (!window.isDestroyed()) {
                window.close();
            }
            profileWindows.delete(profileId);
        }
        
        return true;
    } catch (error) {
        console.error('Error deleting profile:', error);
        throw error;
    }
});

ipcMain.handle('launch-profile', async (event, profileId) => {
    try {
        const profileDir = path.join(PROFILES_DIR, profileId);
        const configPath = path.join(profileDir, 'config.json');
        
        if (!fs.existsSync(configPath)) {
            throw new Error('Profile not found');
        }
        
        const profile = JSON.parse(fs.readFileSync(configPath, 'utf8'));
        console.log(`Launching profile: ${profile.name} (${profileId})`);
        
        // Закрываем предыдущее окно если оно открыто
        if (profileWindows.has(profileId)) {
            const existingWindow = profileWindows.get(profileId);
            if (!existingWindow.isDestroyed()) {
                existingWindow.close();
            }
        }
        
        // Создаем новое окно браузера
        const browserWindow = new BrowserWindow({
            width: parseInt(profile.screenWidth) || 1920,
            height: parseInt(profile.screenHeight) || 1080,
            title: `AEZAKMI Pro — ${profile.name}`,
            webPreferences: {
                partition: `persist:aezakmi_${profileId}`,
                contextIsolation: false,
                nodeIntegration: false,
                webSecurity: false,
                allowRunningInsecureContent: true
            }
        });
        
        profileWindows.set(profileId, browserWindow);
        
        // Настройка прокси если указан
        if (profile.proxy && profile.proxy.enabled && profile.proxy.host && profile.proxy.port) {
            const proxyUrl = `${profile.proxy.type || 'http'}://${profile.proxy.host}:${profile.proxy.port}`;
            console.log(`Setting proxy: ${proxyUrl}`);
            
            await browserWindow.webContents.session.setProxy({
                proxyRules: proxyUrl,
                proxyBypassRules: 'localhost,127.0.0.1'
            });
        }
        
        // Устанавливаем User Agent
        if (profile.userAgent && profile.userAgent !== 'auto') {
            browserWindow.webContents.setUserAgent(profile.userAgent);
        }
        
        // Загружаем стартовую страницу
        const startUrl = profile.startUrl || 'https://whoer.net/ru';
        console.log(`Loading start URL: ${startUrl}`);
        
        browserWindow.loadURL(startUrl).catch(error => {
            console.error(`Failed to load URL: ${startUrl}`, error);
        });
        
        // Применяем антидетект скрипты после загрузки страницы
        browserWindow.webContents.on('did-finish-load', () => {
            console.log(`Applying fingerprint spoofing for profile ${profileId}`);
            
            const spoofingScript = `
                (function() {
                    // Canvas fingerprint spoofing
                    if (${profile.antidetect?.canvasNoise !== false}) {
                        const originalGetImageData = CanvasRenderingContext2D.prototype.getImageData;
                        CanvasRenderingContext2D.prototype.getImageData = function() {
                            const imageData = originalGetImageData.apply(this, arguments);
                            const data = imageData.data;
                            for (let i = 0; i < data.length; i += 4) {
                                data[i] = Math.min(255, Math.max(0, data[i] + Math.floor(Math.random() * 5 - 2)));
                                data[i + 1] = Math.min(255, Math.max(0, data[i + 1] + Math.floor(Math.random() * 5 - 2)));
                                data[i + 2] = Math.min(255, Math.max(0, data[i + 2] + Math.floor(Math.random() * 5 - 2)));
                            }
                            return imageData;
                        };
                    }
                    
                    // WebGL fingerprint spoofing
                    if (${profile.antidetect?.webglNoise !== false}) {
                        const originalGetParameter = WebGLRenderingContext.prototype.getParameter;
                        WebGLRenderingContext.prototype.getParameter = function(parameter) {
                            if (parameter === 37445) { // UNMASKED_VENDOR_WEBGL
                                return 'Intel Inc.';
                            }
                            if (parameter === 37446) { // UNMASKED_RENDERER_WEBGL
                                return 'Intel Iris OpenGL Engine';
                            }
                            return originalGetParameter.apply(this, arguments);
                        };
                    }
                    
                    // Audio context spoofing
                    if (${profile.antidetect?.audioNoise !== false}) {
                        const originalGetFloatFrequencyData = AnalyserNode.prototype.getFloatFrequencyData;
                        AnalyserNode.prototype.getFloatFrequencyData = function(array) {
                            originalGetFloatFrequencyData.apply(this, arguments);
                            for (let i = 0; i < array.length; i++) {
                                array[i] += Math.random() * 0.0001 - 0.00005;
                            }
                        };
                    }
                    
                    // WebRTC blocking
                    if (${profile.antidetect?.blockWebRTC !== false}) {
                        delete window.RTCPeerConnection;
                        delete window.webkitRTCPeerConnection;
                        delete window.mozRTCPeerConnection;
                        if (navigator.mediaDevices) {
                            delete navigator.mediaDevices.getUserMedia;
                        }
                    }
                    
                    // Screen resolution spoofing
                    if ('${profile.screenWidth}' && '${profile.screenHeight}') {
                        Object.defineProperty(screen, 'width', { value: ${profile.screenWidth || 1920} });
                        Object.defineProperty(screen, 'height', { value: ${profile.screenHeight || 1080} });
                        Object.defineProperty(screen, 'availWidth', { value: ${profile.screenWidth || 1920} });
                        Object.defineProperty(screen, 'availHeight', { value: ${(profile.screenHeight || 1080) - 40} });
                    }
                    
                    // Language spoofing
                    if ('${profile.language}') {
                        Object.defineProperty(navigator, 'language', { value: '${profile.language || 'ru-RU'}' });
                        Object.defineProperty(navigator, 'languages', { value: ['${profile.language || 'ru-RU'}', 'en-US', 'en'] });
                    }
                    
                    // Timezone spoofing
                    if ('${profile.timezone}') {
                        const originalGetTimezoneOffset = Date.prototype.getTimezoneOffset;
                        Date.prototype.getTimezoneOffset = function() {
                            return ${profile.timezoneOffset || -180}; // Moscow timezone by default
                        };
                    }
                    
                    // Geolocation spoofing
                    if (${profile.antidetect?.spoofGeolocation === true} && '${profile.latitude}' && '${profile.longitude}') {
                        const originalGetCurrentPosition = navigator.geolocation.getCurrentPosition;
                        navigator.geolocation.getCurrentPosition = function(success, error, options) {
                            success({
                                coords: {
                                    latitude: ${profile.latitude || 55.7558},
                                    longitude: ${profile.longitude || 37.6176},
                                    accuracy: 20,
                                    altitude: null,
                                    altitudeAccuracy: null,
                                    heading: null,
                                    speed: null
                                },
                                timestamp: Date.now()
                            });
                        };
                    }
                    
                    console.log('AEZAKMI antidetect spoofing applied');
                })();
            `;
            
            browserWindow.webContents.executeJavaScript(spoofingScript).catch(error => {
                console.error('Error applying spoofing script:', error);
            });
        });
        
        // Обработка закрытия окна
        browserWindow.on('closed', () => {
            profileWindows.delete(profileId);
        });
        
        return { success: true, profileId };
        
    } catch (error) {
        console.error('Error launching profile:', error);
        throw error;
    }
});

// IPC Handlers для прокси
ipcMain.handle('get-proxies', async () => {
    try {
        if (fs.existsSync(PROXIES_FILE)) {
            const data = fs.readFileSync(PROXIES_FILE, 'utf8');
            return JSON.parse(data);
        }
        return [];
    } catch (error) {
        console.error('Error getting proxies:', error);
        return [];
    }
});

ipcMain.handle('save-proxies', async (event, proxies) => {
    try {
        fs.writeFileSync(PROXIES_FILE, JSON.stringify(proxies, null, 2));
        return true;
    } catch (error) {
        console.error('Error saving proxies:', error);
        throw error;
    }
});

ipcMain.handle('test-proxy', async (event, proxy) => {
    try {
        // Простая проверка прокси через HTTP запрос
        const { net } = require('electron');
        const proxyUrl = `${proxy.type}://${proxy.host}:${proxy.port}`;
        
        return new Promise((resolve) => {
            const request = net.request({
                method: 'GET',
                url: 'http://httpbin.org/ip',
                session: session.fromPartition(`proxy-test-${Date.now()}`)
            });
            
            request.on('response', (response) => {
                if (response.statusCode === 200) {
                    resolve({ success: true, status: 'working' });
                } else {
                    resolve({ success: false, status: 'failed' });
                }
            });
            
            request.on('error', () => {
                resolve({ success: false, status: 'failed' });
            });
            
            setTimeout(() => {
                request.abort();
                resolve({ success: false, status: 'timeout' });
            }, 10000);
            
            request.end();
        });
    } catch (error) {
        console.error('Error testing proxy:', error);
        return { success: false, status: 'failed' };
    }
});

// Обработка ошибок
process.on('uncaughtException', (error) => {
    console.error('Uncaught Exception:', error);
});

process.on('unhandledRejection', (error) => {
    console.error('Unhandled Rejection:', error);
});